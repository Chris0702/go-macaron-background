hteditor.customStrings = { 
    
};
