hteditor.customStrings = { 
    
};

