hteditor.customStrings = {
     
};

