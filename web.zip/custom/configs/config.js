window.hteditor_config = {
    locale: 'zh_tw',
    color_select: '#F37920',
    color_line: '#F37920' ,//line
    // color_select: 'blue',
    // imageSize: 200,
    // fileRemovableByKeyboard: true,
    // locateFileEnabled: false,
    // promptBeforeClosing: false,
    displayPreviewURL:'display.html',
    serviceClass: 'EditorService',
    traceMissingI18n: true,
    expandedTitles: {
        TitleExtension: false
    },
    subConfigs: [
        'custom/libs/Service.js',
        'custom/configs/config-handleEvent.js',
        'custom/configs/config-valueTypes.js',
        'custom/configs/config-dataBindings.js',
        'custom/configs/config-inspectorFilter.js',
        'custom/configs/config-customProperties.js',
        'custom/configs/config-onTitleCreating.js',
        'custom/configs/config-onMainToolbarCreated.js',
        'custom/configs/config-onMainMenuCreated.js',
        'custom/configs/config-onRightToolbarCreated.js'
    ],
    libs: [
        'custom/libs/echarts.js'
    ]
};