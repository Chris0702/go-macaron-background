/**
 * data.setDataBindings({
 *     p: {
 *         name: { id: 'M001' },
 *         icon: {
 *             id: 'M002',
 *             func: function(value) {
 *                 if (value > 70) {
 *                     return 'symbols/scada/alarm.json';
 *                 }
 *                 if (value > 50) {
 *                     return 'symbols/scada/warning.json';
 *                 }
 *                 return 'symbols/scada/normal.json';
 *             }
 *         }
 *     },
 *     s: {
 *         'shape.background': {
 *             id: 'M002'
 *             func: function(value) {
 *                 if (value > 70) {
 *                     return 'red';
 *                 }
 *                 if (value > 50) {
 *                     return 'yellow';
 *                 }
 *                 return 'green';
 *             }
 *         }
 *         'shape.border.width': { id: 'M003' },
 *     },
 *     a: {
 *         'pressure': { id: 'M004' },
 *         'temperature': { id: 'M005' },
 *         'volume': { id: 'M006' }
 *     }
 * });
 */




window.hteditor_config.dataBindings = {

    onButtonClicked: function(data, accessType, name) {
        var dialog = new ht.widget.Dialog();
        var dataBindings = data.getDataBindings();
        console.info('onButtonClicked','data',data,'accessType',accessType,'name',name,'dataBindings',dataBindings);
        var id = '';
        var func = null,sourceType = null, sourceObj = {},targets = [],animatedOptions = {};
        if (dataBindings && dataBindings[accessType] && dataBindings[accessType][name]) {
            id = dataBindings[accessType][name].id;
            func = dataBindings[accessType][name].func;
            animatedOptions = dataBindings[accessType][name].animatedOptions;
            // sourceType = dataBindings[accessType][name].sourceType?dataBindings[accessType][name].sourceType:'simulation';
            targets = dataBindings[accessType][name].targets?dataBindings[accessType][name].targets:[];
        }else{
            // sourceType = 'simulation';
            targets = [];
        }
        //create unique id
        if(!id){
            id = commonUtil.getUniqueId();
        }

        var S = hteditor.getString;
        var formPane = new ht.widget.FormPane();
        var animateFormPane = new ht.widget.FormPane();
        var sourceFormPane = new ht.widget.FormPane();

        // property formPane
        formPane.addRow([
            S('Property'),
            {
                textField: {
                    text: name,
                    editable: false
                }
            }
        ], [50, 0.1]);
        formPane.addRow([
            S('Id'),
            {
                id: 'input',
                textField: {
                    text: id
                }
            }
        ], [50, 0.1]);

        // animate formPane
        animationPropUI.initUI(animateFormPane, accessType, name,animatedOptions);


        // source formPane
        dataBindingUI.initRenderSourceUI(sourceFormPane, targets);



        console.info('formPane',formPane,formPane.getRows());

        
        var buttons = [{
            label: S('Cancel'),
            action: function() {
                dialog.hide();
            }
        }, {
            label: S('clear'),
            action: function() {
                var dataBindings = data.getDataBindings();
                if (!dataBindings) {
                    dataBindings = {};
                }
                if (!dataBindings[accessType]) {
                    dataBindings[accessType] = {};
                }
                if (!dataBindings[accessType][name]) {
                    dataBindings[accessType][name] = {};
                }
                dataBindings[accessType][name] = null;
                delete dataBindings[accessType][name];
                data.setDataBindings(dataBindings);
                data.fp('dataBindings', true, false);
                dialog.hide();
            }
        }, {
            label: S('OK'),
            action: function() {
                var id = formPane.v('input');
                // var func = animateFormPane.v('textArea');
                //var sourceType = sourceFormPane.v('sourceType');
                // var formatType = sourceFormPane.v('formatType');
                // var target = sourceFormPane.v('target');
                // var sourceObj = {};
                var animatedOptions = animationPropUI.getAnimateUIValue(animateFormPane, accessType, name);
                console.log('animatedOptions',animatedOptions);
                var targets = [];
                //get data source 
                //sourceObj = dataBindingUI.getSourceUIValue(sourceFormPane,sourceObj);
                targets = dataBindingUI.getSourceUIValue(sourceFormPane);
                console.log('targets',targets);
                //temp scada
                // if(sourceType == 'scada'){
                //     sourceObj.node = sourceFormPane.v('node');
                //     sourceObj.device = sourceFormPane.v('device');
                //     sourceObj.tag = sourceFormPane.v('tag');
                //     console.log(sourceObj.node,sourceObj.device,sourceObj.tag);
                // }

                // alert('source:'+source);
                var dataBindings = data.getDataBindings();
                if (!dataBindings) {
                    dataBindings = {};
                }
                if (!dataBindings[accessType]) {
                    dataBindings[accessType] = {};
                }
                if (!dataBindings[accessType][name]) {
                    dataBindings[accessType][name] = {};
                }
                if (!id) {
                    delete dataBindings[accessType][name];
                }
                else {
                    dataBindings[accessType][name].id = id;
                    // dataBindings[accessType][name].func = hteditor.parseFunction(func);
                    // dataBindings[accessType][name].sourceType = sourceType;
                    dataBindings[accessType][name].animatedOptions = animatedOptions;
                    dataBindings[accessType][name].targets = targets;
                }
                data.setDataBindings(dataBindings);
                data.fp('dataBindings', true, false);
                dialog.hide();
            }
        }];


        //tab View
        var tabView = new ht.widget.TabView();
        // tabView.setSelectBackground('#D26911');
        // tabView.setTabBackground('#F5F5F5');
        tabView.setLabelColor('#FFFFFF'); 
        // create Source tab
        var tabSource = new ht.Tab();
        tabSource.setName('Data source');
        tabSource.setView(sourceFormPane); 
        // create Animation tab
        var tabAnimate = new ht.Tab();
        tabAnimate.setName('Animation');
        tabAnimate.setView(animateFormPane); 
        // create Info tab
        var tabInfo = new ht.Tab();
        tabInfo.setName('Info');
        tabInfo.setView(formPane); 
        // add tab to tabView model
        var tabModel = tabView.getTabModel();
        tabModel.add(tabSource);   
        tabModel.add(tabAnimate);  
        tabModel.add(tabInfo);  
        //select default
        tabModel.getSelectionModel().setSelection(tabSource);

        //Split view
        var infoPane = new ht.widget.FormPane();
        var mainView = new ht.widget.SplitView(infoPane, tabView, 'v', 30); 
        mainView.setDividerSize(0);



        dialog.setConfig({
            title: S('Data Binding'),
            draggable: true,
            width: 500,
            height: 500,
            contentPadding: 4,
            content: mainView,
            buttons: buttons,
            buttonsAlign: 'right'
        });


        dialog.show();
        formPane.getViewById('input').setFocus();
    }
};